#include<stdio.h>
Int main(){
Printf(“hello world”);
Return 0;
}